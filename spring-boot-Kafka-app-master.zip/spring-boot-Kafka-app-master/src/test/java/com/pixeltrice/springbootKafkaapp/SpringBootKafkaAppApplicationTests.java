package com.pixeltrice.springbootKafkaapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootKafkaAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
