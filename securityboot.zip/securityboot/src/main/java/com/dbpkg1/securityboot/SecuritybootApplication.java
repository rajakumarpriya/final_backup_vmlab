package com.dbpkg1.securityboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecuritybootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecuritybootApplication.class, args);
	}

}
