package com.example.Kafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringHibernateKafkaOrderedApplicationTests {

	@Test
	void contextLoads() {
	}

}
