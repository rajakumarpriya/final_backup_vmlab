package com.dbook.reader.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.dbook.reader.entities.BuyBook;
import com.dbook.reader.repository.ReaderRepository;

import java.util.List;

@Service
public class ReaderService {
    @Autowired
    private ReaderRepository repository;

   
	public BuyBook buyBook(BuyBook book) {
		// TODO Auto-generated method stub
		return repository.save(book);
	}

    public List<BuyBook> getAllPurBooks() {
        return repository.findAll();
    }
//
//    public Author getAuthorById(int id) {
//        return repository.findById(id).orElse(null);
//    }
//
//    public Author getAuthorByName(String name) {
//        return repository.findByUsername(name);
//    }
//
//    public Author updateAuthor(Author author) {
//        Author existingAuthor = repository.findById(author.getId()).orElse(null);
//        existingAuthor.setUsername(author.getUsername());
//        existingAuthor.setPassword(author.getPassword());
//        existingAuthor.setRole(author.getRole());
//        return repository.save(existingAuthor);
//    }


}
