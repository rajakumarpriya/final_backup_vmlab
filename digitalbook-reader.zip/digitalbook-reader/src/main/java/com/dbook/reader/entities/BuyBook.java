package com.dbook.reader.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "Buybook")
public class BuyBook {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private int bookid;
	private String readername;
	private String readermail;
  
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public String getReadername() {
		return readername;
	}
	public void setReadername(String readername) {
		this.readername = readername;
	}
	public String getReadermail() {
		return readermail;
	}
	public void setReadermail(String readermail) {
		this.readermail = readermail;
	}
	@Override
	public String toString() {
		return "BuyBook [id=" + id + ", bookid=" + bookid + ", readername=" + readername + ", readermail=" + readermail
				+ "]";
	}
	public BuyBook() {
		// TODO Auto-generated constructor stub
	}
	
	public BuyBook(int bookid, String readername, String readermail) {
		this.bookid = bookid;
		this.readername = readername;
		this.readermail = readermail;
	}
	public BuyBook(int id, int bookid, String readername, String readermail) {
		super();
		this.id = id;
		this.bookid = bookid;
		this.readername = readername;
		this.readermail = readermail;
	}
	
	
	
}
