package com.dbook.reader.controller;

import com.dbook.reader.entity.Reader;
import com.dbook.reader.service.ReaderService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/reader")
public class ReaderController {
	
    @Autowired
    private ReaderService service;
    
    @GetMapping("/searchByCategory")
    public List<Reader> searchByCategory() {
        return service.getAuthors();
    }
    @GetMapping("/searchByPrice")
    public List<Reader> searchByPrice() {
        return service.getAuthors();
    }
    @GetMapping("/searchByAuthor")
    public List<Reader> searchByAuthor() {
        return service.getAuthors();
    }
    @GetMapping("/searchByPublisher")
    public List<Reader> searchByPublisher() {
        return service.getAuthors();
    }

    @PostMapping("/buyPayload")
    public Reader buyPayload(@RequestBody Reader author) {
        return service.saveAuthor(author);
    }

    @GetMapping("/getAllPurchasedbooks")
    public List<Reader> getAllPurchasedBooks() {
        return service.getAuthors();
    }

    @GetMapping("/getAllPurchased/{paymentid}")
    public Reader findAuthorByName(@PathVariable int paymentid) {
        return service.getAuthorByName(paymentid);
    }

    

   
}
