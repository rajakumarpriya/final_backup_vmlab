package com.dbook.reader.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;






@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Author")
public class Reader {

    
	
	@Id
	@GeneratedValue
    private int id;
    private String username;
    private String password;
    private String role;
   
	paymentid
	bookid
	email
	username
	
 
	
	
}
