package com.dbook.reader.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dbook.reader.entity.Author;
@Repository
public interface ReaderRepository extends JpaRepository<Author,Integer> {
    Author findByUsername(String username);
}

