package com.dbpkg.digitalbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigitalbookApplicationTests {

	@Test
	void contextLoads() {
	}

}
