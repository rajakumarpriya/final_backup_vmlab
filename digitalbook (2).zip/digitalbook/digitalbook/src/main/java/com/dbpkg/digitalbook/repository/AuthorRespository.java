package com.dbpkg.digitalbook.repository;

public class AuthorRespository {

}
