package com.dbpkg.digitalbook2.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class ArrayListIteratorRemoveExample {
    public static void main(String[] args) {
        List<Integer> numbers = new ArrayList<>();
        numbers.add(13);
        numbers.add(18);
        numbers.add(8);
        numbers.add(40);
        System.out.println("numbers1"+numbers);
        Collections.sort(numbers, new Comparator<Integer>() {
			@Override
			public int compare(Integer o1, Integer o2) {
				return o1.compareTo(o2);
			}
        	
		});
        System.out.println("numbers2"+numbers);
        
        
        
        System.out.println("numbers1"+numbers);
        Collections.sort(numbers, ( o1,  o2) -> o1.compareTo(o2));
			//}
        	
		//});
        System.out.println("numbers21"+numbers);
        List<Integer> numbers1 = new ArrayList<>();
        numbers1.add(13);
        numbers1.add(18);
        numbers1.add(25);
        numbers1.add(40);
        Iterator<Integer> numbersIterator = numbers.iterator();
        ListIterator<Integer> numbersIterator1 = numbers1.listIterator();
        for(Iterator<Integer> t1=numbers.iterator();t1.hasNext();) {
        	System.out.println(t1.next());
        }
        for(Integer s1:numbers) {
        	System.out.println(s1);
        }
        for(int i=0;i<numbers.size();i++) {
        	System.out.println(numbers.get(i));
        }
        while (numbersIterator.hasNext()) {
            Integer num = numbersIterator.next();
            if(num % 2 != 0) {
                numbersIterator.remove();
            }
        }
        while (numbersIterator1.hasNext()) {
            Integer num1 = numbersIterator1.next();
            if(num1 % 2 != 0) {
            	numbersIterator1.remove();
            }
        }

        System.out.println(numbers1);
        System.out.println(numbers);
    }
}