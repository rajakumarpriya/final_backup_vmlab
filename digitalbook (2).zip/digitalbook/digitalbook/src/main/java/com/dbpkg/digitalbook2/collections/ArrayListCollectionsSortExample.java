package com.dbpkg.digitalbook2.collections;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.LinkedBlockingDeque;

public class ArrayListCollectionsSortExample {
    public static void main(String[] args) {
        List<Integer> numbers = new ArrayList<Integer>();
        numbers.add(13);
        numbers.add(7);
        numbers.add(18);
        numbers.add(5);
        numbers.add(2);

        System.out.println("Before : " + numbers);

        // Sorting an ArrayList using Collections.sort() method
        Collections.sort(numbers);

        System.out.println("After : " + numbers);
        ArrayList<Integer> numbers1 = new ArrayList<>();
        numbers1.add(13);
        numbers1.add(7);
        numbers1.add(18);
        numbers1.add(5);
        numbers1.add(2);

        System.out.println("Before : " + numbers1);

        // Sorting an ArrayList using Collections.sort() method
        Collections.sort(numbers1);

        System.out.println("After : " + numbers1);
        LinkedList<Integer> numbers2 = new LinkedList<>();
        numbers2.add(13);
        numbers2.add(7);
        numbers2.add(18);
        numbers2.add(5);
        numbers2.add(2);

        System.out.println("Before : " + numbers2);

        // Sorting an ArrayList using Collections.sort() method
        Collections.sort(numbers2,Collections.reverseOrder());

        System.out.println("After : " + numbers2);
    }
}