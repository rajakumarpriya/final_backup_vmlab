package com.dbpkg.digitalbook.entities;

public class Author {

}
